#if defined(CONFIG_KWD_KITTAI)

#include <stdio.h>
#include <malloc.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>

#include <signal.h>
#include <alsa/asoundlib.h>

#include <console.h>

#include "asp.h"
#include "snowboy-detect.h"

#include "interface.h"

#define RESOURE_FILE_NAME   "/etc/universal_detect.res"
#define RESOURE_MODEL_NAME  "/etc/hotword.umdl"
#define SENSITIVITY         "0.48"

#define SNOWBOY_CHUNK_SIZE  1600
#define BYTES_PER_SAMPLE    2

#define cons NULL

void * snowboy_start_routine(void *args){
	snowboy_main(args);
}
posixThreadOps_t *
int snowboy_main(void *args)
{
    int32 hotword = 0;
    int32 count = SNOWBOY_CHUNK_SIZE;	
    bool is_end = DUER_FALSE;
    int i = 0;
    char str[512];
    unsigned char *asp_audiobuf;
    int samples;
	wakeupStartArgs_t *pStartArgs=(wakeupStartArgs_t *)args;
    /* Initialize audio */
    // CreateMsgPthread();

#if defined(CONFIG_ASP_VEP) || defined(CONFIG_ASP_VEP_OPT) \
   || defined(CONFIG_ASP_SQE) || defined(CONFIG_ASP_YSZ)
    ASP_init();
#endif

    SnowboyInit(RESOURE_FILE_NAME, RESOURE_MODEL_NAME, DUER_TRUE);

    SnowboySetSensitivity(SENSITIVITY);

    while(1)
    {
        sprintf(str,"echo %d > /tmp/wakeloop",i); system(str);
        sprintf(str,"\n===== LOOP %i  ======",i); disp(cons,str);
        disp(cons,"Recording...");

        while (1)
        {
            asp_audiobuf = ASP_acquire_data(&samples);

            hotword = SnowboyRunDetection((const int16_t *) asp_audiobuf, samples ,is_end);
			//修改此处回调	
			pStartArgs->pCallbackArgs->iSwakeupFlag = hotword>0?1:0;

			pStartArgs->pRecordDataInputCallback(asp_audiobuf,samples*2,(void *)pStartArgs->pCallbackArgs);

			if(pStartArgs->pCallbackArgs->ListenStatus){				
//			    SnowboyReset();
			}else{
//				SnowboyReset();				
			}

			SnowboyReset();	
			ASP_release_data();		
        }
    }

    /* Clean up */
    disp(cons,"Done");

    return 0;
}
#endif

