#include "interface.h"

#define _GNU_SOURCE
#include <sched.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "string.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int my_clone(int (*func)(void*),void *args,int flag,int stack_size){
	void *stack = malloc(stack_size);
	if (stack == NULL){
		show_errno(0,"malloc");
		return -1;
	}	  
	void *stackTop = stack + stack_size;
	pid_t pid = clone(func,stackTop,flag,args);
	if (pid <0){
		show_errno(0,"clone");
		return -2;		
	}
    return pid;
}

static char ListenStatus =0;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

char getListenStatus(void){
	char status=0;
	pthread_mutex_lock(&mutex);
	status=ListenStatus;
	pthread_mutex_unlock(&mutex);
	return status;
}

void setListenStatus(char status){
	pthread_mutex_lock(&mutex);
	ListenStatus=status;
	pthread_mutex_unlock(&mutex);
}
char getListenStatusNoLock(void){
	return ListenStatus;
}

void setListenStatusNoLock(char status){
	ListenStatus=status;
}


static char MutMicStatus =0;
static pthread_mutex_t MutMicMtx = PTHREAD_MUTEX_INITIALIZER;

char getMutMicStatus(void){
	char status=0;
	pthread_mutex_lock(&MutMicMtx);
	status=MutMicStatus;
	pthread_mutex_unlock(&MutMicMtx);
	return status;
}

void setMutMicStatus(char status){
	pthread_mutex_lock(&MutMicMtx);
	MutMicStatus=status;
	pthread_mutex_unlock(&MutMicMtx);
}
wakeupStartArgs_t *wakeupStartArgs = NULL;

int wakeupStart(wakeupStartArgs_t *pArgs){	
	
#if defined(CONFIG_KWD_KITTAI)
	extern void * snowboy_start_routine(void *args);
	pArgs->pStart_routine=snowboy_start_routine;
#endif
#if defined(CONFIG_KWD_SENSORY)
	extern void * sensory_start_routine(void *args);
	pArgs->pStart_routine=sensory_start_routine;
#endif	
#if 1
//	err("user pthread to start thread!");
	int err=pthread_create(&pArgs->wakeupPthreadId,pArgs->pAttr,pArgs->pStart_routine,pArgs);
	if(err){
		show_errno(err,"pthread_create");
		return -1;
	}
#else
//	err("user clone to start thread!");
#define CLONE_FLAGS (CLONE_THREAD|CLONE_SIGHAND|CLONE_VM)
	int err=my_clone(pArgs->pStart_routine,pArgs,CLONE_FLAGS,1024*1024);
	if(err<0){
		show_errno(err,"pthread_create");
		return -1;
	}
#endif
	return 0;
}


