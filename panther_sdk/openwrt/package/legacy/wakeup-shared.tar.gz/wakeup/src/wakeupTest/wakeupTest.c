#include <pthread.h>
#include "../interface.h"



void recordDataInputCallback(char* buffer, long unsigned int size, void *userdata){
	setListenStatus(0);
	//inf("已唤醒，正在上传语音数据。。。");
	usleep(10*1000);
	
}
static userTimer_t* stopListenUserTimerPtr=NULL;
static void stopListenTimeOutCallback(int sig){
	inf_nl(__func__);
	setListenStatusNoLock(0);
	stopListenUserTimerPtr->stop(stopListenUserTimerPtr);
}
int main(int argc,char *argv[]){

	clog(Hred,"compile in [%s %s]",__DATE__,__TIME__);
	unlink("/tmp/tid.rec");
	showProcessThreadId("");
	log_init(argv[1]);

	wakeupStartArgs_t wakeupStartArgs={0};

	sensory_init();

	wakeupStartArgs.wakeup_mode=1;
	struct sched_param param;
	pthread_attr_t attr; 
	pthread_attr_init(&attr);
	param.sched_priority = 60;	
	pthread_attr_setschedpolicy (&attr, SCHED_RR);
	pthread_attr_setschedparam(&attr, &param);
	pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
	wakeupStartArgs.pAttr=&attr;
    int err  = wakeupStart(&wakeupStartArgs);
	if(err<0){
		err("wakeupStart failure,err=%u",err);
		return -2;
	}
	inf("recorder thread is OK!");
	while(1)pause();
	return 0;
}
