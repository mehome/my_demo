#ifndef WAKEUP_INTERFACE_H_
#define WAKEUP_INTERFACE_H_
#include <libcchip/platform.h>
#include <libcchip/function/user_timer/user_timer.h>

typedef void *(*pStart_routine_t) (void *);
int sensory_init(void);

char getListenStatus(void);
void setListenStatus(char status);
void setListenStatusNoLock(char status);
char getListenStatusNoLock(void);


void setMutMicStatus(char status);
char getMutMicStatus(void);


typedef struct wakeupStartArgs_t{	
	void *PortAudioMicrophoneWrapper_ptr;
	void (*pRecordDataInputCallback)(char* buffer, long unsigned int size, void *userdata);	
	pthread_t wakeupPthreadId;
	pStart_routine_t pStart_routine;
	pthread_attr_t *pAttr;
	char isWakeUpSucceed;
	userTimer_t* userTimerPtr;
	int wakeup_mode;
	posixThreadOps_t *wakeup_waitctl;
}wakeupStartArgs_t;

int wakeupStart(wakeupStartArgs_t *pArgs);
int sensory_init(void);

#endif
