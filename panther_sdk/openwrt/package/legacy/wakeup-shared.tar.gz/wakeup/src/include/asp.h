#ifndef __ASP_H__
#define __ASP_H__
#include "../interface.h"

typedef struct ASP_args_t{
	int samples;
	char *buf;
	void *otherArgs;
}ASP_args_t;

void ASP_acquire_data(ASP_args_t *args);
int ASP_init(ASP_args_t *args);
void ASP_release_data(void);
void ASP_clear_data(void);

#endif //__ASP_H__
