Each version of gRPC gets a new description of what the 'g' stands for, since
we've never really been able to figure it out.

Below is a list of already-used definitions (that should not be repeated in the
future), and the corresponding version numbers that used them:

- 1.0 'g' stands for 'gRPC'
- 1.1 'g' stands for 'good'
- 1.2 'g' stands for 'green'
- 1.3 'g' stands for 'gentle'
- 1.4 'g' stands for 'gregarious'
- 1.6 'g' stands for 'garcia'
- 1.7 'g' stands for 'gambit'
