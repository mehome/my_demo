# Resolver

Implementations of various name resolution schemes.
See the [naming spec](/doc/naming.md).
