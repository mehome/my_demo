var structlws__cgi__args =
[
    [ "ch", "structlws__cgi__args.html#adeee220b29aeacc34632c38e50f0f5a5", null ],
    [ "data", "structlws__cgi__args.html#a8ac842084688c02f3f94694ef700d8f7", null ],
    [ "hdr_state", "structlws__cgi__args.html#a741c11b9aa05997ec45a3400d7fb7739", null ],
    [ "len", "structlws__cgi__args.html#a36e5c256433c187bd0eaa9c1ca667f1d", null ],
    [ "stdwsi", "structlws__cgi__args.html#a4ccc1058e7e914a26eef31ab2ad46aa1", null ]
];