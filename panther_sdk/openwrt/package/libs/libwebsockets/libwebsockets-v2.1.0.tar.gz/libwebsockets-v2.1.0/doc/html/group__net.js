var group__net =
[
    [ "lws_canonical_hostname", "group__net.html#gad0df22db2be9fc65a667a1e83f9a92a4", null ],
    [ "lws_get_peer_addresses", "group__net.html#ga092e5f473b3347f03ffeef8a950080f3", null ],
    [ "lws_get_peer_simple", "group__net.html#gad01014fed09759741b6d23afccfdaacc", null ],
    [ "lws_interface_to_sa", "group__net.html#ga869d8bdffb0f2a7ce08e3ce10d6be3d8", null ]
];