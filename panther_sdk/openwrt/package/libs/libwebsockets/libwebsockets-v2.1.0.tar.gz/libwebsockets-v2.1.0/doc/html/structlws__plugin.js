var structlws__plugin =
[
    [ "caps", "structlws__plugin.html#ac7f1fdfe8cf8a21f8ee9720c21934a3f", null ],
    [ "l", "structlws__plugin.html#a4ef37a43653715b6c69cbf8a7be747f4", null ],
    [ "lib", "structlws__plugin.html#af9e1042dc1de5b9d202c2f5fd1834330", null ],
    [ "list", "structlws__plugin.html#a65dffd68fd267ce17b988790d1d35f22", null ],
    [ "name", "structlws__plugin.html#af4ac8fcb79e10e0c2d960e1804d98105", null ]
];