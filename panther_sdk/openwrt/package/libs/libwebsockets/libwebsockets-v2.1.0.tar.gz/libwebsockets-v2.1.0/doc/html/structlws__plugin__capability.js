var structlws__plugin__capability =
[
    [ "api_magic", "structlws__plugin__capability.html#a523c7cde6f15bba345f56493dcf6b32a", null ],
    [ "count_extensions", "structlws__plugin__capability.html#abcf51db969522fdda9aaf902e65739d3", null ],
    [ "count_protocols", "structlws__plugin__capability.html#ae38f7cf1246b9ca3af3cbf9d46b7090f", null ],
    [ "extensions", "structlws__plugin__capability.html#a7936f0eb93d79dea76b903d0f8a5f623", null ],
    [ "protocols", "structlws__plugin__capability.html#a6a4d9d01e770f378ddadc77b37522033", null ]
];