var group__HTTP_headers_create =
[
    [ "lws_add_http_header_by_name", "group__HTTP-headers-create.html#ga2b36bf44405755ff51c1939303b995a8", null ],
    [ "lws_add_http_header_by_token", "group__HTTP-headers-create.html#gaf74adb761b22566ad70004882712dce1", null ],
    [ "lws_add_http_header_content_length", "group__HTTP-headers-create.html#gacc76a5babcb4dce1b01b1955aa7a2faf", null ],
    [ "lws_add_http_header_status", "group__HTTP-headers-create.html#ga29b7d6d2ddfdbaff3d8b607e7e3151b6", null ],
    [ "lws_finalize_http_header", "group__HTTP-headers-create.html#ga4887605ff2242a54db3a7fa01f6f864b", null ]
];